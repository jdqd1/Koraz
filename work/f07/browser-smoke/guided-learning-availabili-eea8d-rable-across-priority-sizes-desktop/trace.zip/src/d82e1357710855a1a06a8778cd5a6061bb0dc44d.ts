import { test, expect, type Page } from "@playwright/test";
import { writeFile } from "node:fs/promises";
import AxeBuilder from "@axe-core/playwright";

const api = "http://127.0.0.1:41035";
async function actor(page: Page, name: string) {
  await page.context().addCookies([{ name: "t035", value: name, domain: "127.0.0.1", path: "/" }]);
}
type Trace = { method: string; path: string; status: number; durationMs: number; bytes: number; reference?: string; requestId?: string };
const percentile = (values: number[], p: number) => [...values].sort((a, b) => a - b)[Math.ceil(values.length * p) - 1]!;
const fault = (page: Page, value: string) => page.context().addCookies([{ name: "f07_fault", value, domain: "127.0.0.1", path: "/" }]);
const restore = (page: Page) => page.context().clearCookies({ name: "f07_fault" });

test("F07 keeps the answer, feedback and exit operable across priority sizes", async ({ page }, info) => {
  test.skip(process.env.F07_BASELINE === "true");
  await actor(page, info.project.name === "mobile" ? "student-27" : "student-26");
  const ready = await (await page.request.get(`${api}/__test/ready`)).json();
  const enrollment = await page.request.post("/api/v2/guided-learning/enrollments", {
    data: { pathId: ready.fixtures.small.pathId }, headers: { "idempotency-key": crypto.randomUUID() },
  });
  expect(enrollment.status()).toBe(200);
  await page.goto("/aprendizaje/rutas/t035-small?leccion=unit");
  const action = page.locator("#actividad-short-1").getByRole("button", { name: "Abrir actividad", exact: true });
  const start = performance.now();
  await action.click();
  const field = page.getByRole("textbox", { name: "Tu respuesta", exact: true });
  await expect(field).toBeEnabled();
  const launchMs = performance.now() - start;
  const submit = page.getByRole("button", { name: "Comprobar respuesta", exact: true });
  const sizes = [[320, 740], [360, 800], [390, 844], [430, 932], [844, 390], [390, 420], [1024, 768], [1280, 800], [1440, 900], [1920, 1080]];
  const original = page.viewportSize()!;
  const geometry = [];
  for (const [width, height] of sizes as [number, number][]) {
    await page.setViewportSize({ width, height });
    await field.focus();
    await field.fill("respuesta");
    await field.press("Tab");
    await expect(page.getByRole("button", { name: "Necesito ayuda" })).toBeFocused();
    await submit.scrollIntoViewIfNeeded();
    const result = await submit.evaluate(el => {
      const b = el.getBoundingClientRect(), hit = document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2);
      return { width: innerWidth, height: innerHeight, targetHeight: b.height, reachable: el.contains(hit),
        overflows: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1 };
    });
    expect(result, `${width}×${height}`).toMatchObject({ reachable: true, overflows: false });
    expect(result.targetHeight).toBeGreaterThanOrEqual(44);
    geometry.push(result);
  }
  await page.setViewportSize(original);
  const feedbackStart = performance.now();
  if (info.project.name === "mobile") await submit.tap();
  else { await submit.focus(); await submit.press("Enter"); }
  const feedback = page.getByRole("heading", { name: "Respuesta correcta", exact: true });
  await expect(feedback).toBeFocused();
  const responseMs = performance.now() - feedbackStart;
  const violations = (await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"]).analyze()).violations;
  await writeFile(info.outputPath("answer-geometry.json"), JSON.stringify({ geometry, launchMs, responseMs, violations: violations.map(item => ({ id: item.id, targets: item.nodes.map(node => node.target) })) }, null, 2));
  expect(violations.map(item => ({ id: item.id, targets: item.nodes.map(node => node.target) }))).toEqual([]);
  await page.getByRole("button", { name: "Continuar", exact: true }).press("Enter");
  await page.getByRole("button", { name: "Finalizar sesión", exact: true }).press("Enter");
  await expect(page.getByRole("heading", { name: "Sesión completada", exact: true })).toBeFocused();
  await page.getByRole("link", { name: "Volver a la unidad", exact: true }).first().press("Enter");
  await expect(page.locator("#actividad-short-1")).toBeFocused();
});

test("F07 preserves resource section, attempt and catalog context across temporary failures", async ({ page }, info) => {
  test.skip(process.env.F07_BASELINE === "true");
  const actorName = `f06-${info.project.name}`;
  await actor(page, actorName);
  const route = "/aprendizaje/rutas/simulacion-f06";
  const counts = async () => (await (await page.request.get(api + "/__test/counts")).json());
  const before = await counts();
  await fault(page, "catalog");
  await page.goto("/aprendizaje?tab=rutas");
  const failure = page.getByRole("alert").filter({ hasText: "No pudimos cargar tus rutas de práctica por objetivos" });
  await expect(failure).toBeVisible();
  await expect(page.getByRole("link", { name: "Abrir ruta Simulación de navegación F06" })).toBeVisible();
  await restore(page);
  await failure.getByRole("link", { name: "Reintentar" }).click();
  await expect(failure).toHaveCount(0);
  await expect(page).toHaveURL(/tab=rutas/);
  await page.goto(`${route}?leccion=lectura&pestana=resources`);
  await page.getByRole("link", { name: "Consultar Lectura con seguimiento" }).click();
  await page.getByRole("button", { name: "Siguiente", exact: true }).click();
  await expect(page).toHaveURL(/seccion=1/);
  const readerUrl = page.url();
  await fault(page, "resource");
  await page.reload();
  await expect(page.getByRole("heading", { name: "Lectura no disponible" })).toBeVisible();
  await restore(page);
  await page.getByRole("link", { name: "Reintentar lectura" }).click();
  await expect(page.getByText("La letra B sigue a A.", { exact: true })).toBeVisible();
  await expect(page).toHaveURL(readerUrl);
  expect(await counts()).toEqual(before);
  await page.getByRole("link", { name: "Volver a los recursos de la unidad" }).click();
  await page.getByRole("tab", { name: "Recursos" }).focus();
  await page.keyboard.press("ArrowLeft");
  await expect(page.getByRole("tab", { name: "Actividades" })).toBeFocused();
  await fault(page, "progress");
  await page.reload();
  await expect(page.getByRole("heading", { name: "No pudimos cargar tu progreso" })).toBeVisible();
  await expect(page.getByRole("button", { name: /Lectura con seguimiento/ })).toHaveCount(0);
  await restore(page);
  await page.getByRole("link", { name: "Reintentar progreso" }).click();
  await page.getByRole("button", { name: /Lectura con seguimiento/ }).click();
  await expect(page.getByRole("button", { name: "Siguiente", exact: true })).toBeVisible();
  const sessionUrl = page.url();
  const open = await counts();
  await fault(page, "attempt");
  await page.reload();
  await expect(page.getByRole("heading", { name: "No pudimos recuperar la sesión" })).toBeVisible();
  await restore(page);
  await page.getByRole("link", { name: "Reintentar", exact: true }).click();
  await expect(page.getByRole("button", { name: "Siguiente", exact: true })).toBeVisible();
  await expect(page).toHaveURL(sessionUrl);
  expect(await counts()).toEqual(open);
  await page.getByRole("link", { name: "Volver a la unidad", exact: true }).first().click();
  await expect(page.locator('[id^="actividad-"]:focus')).toHaveCount(1);
});

test("F07 correlates the retry and preserves the deep link on expired identity", async ({ page }, info) => {
  test.skip(process.env.F07_BASELINE === "true");
  const name = info.project.name === "mobile" ? "student-36" : "student-35";
  await actor(page, name);
  await fault(page, "identity-once");
  const path = "/aprendizaje/rutas/t035-small?leccion=unit&pestana=resources";
  await page.goto(path);
  await expect(page.getByRole("tab", { name: "Recursos" })).toHaveAttribute("aria-selected", "true");
  const trace: Trace[] = await (await page.request.get(`${api}/__test/trace/${name}`)).json();
  const identity = trace.filter(item => item.path === "/v1/auth/me");
  expect(identity.slice(0, 2).map(item => item.status)).toEqual([503, 200]);
  expect(identity[0]?.reference).toBeTruthy();
  expect(identity[0]?.reference).toBe(identity[1]?.reference);
  expect(identity[0]?.requestId).not.toBe(identity[1]?.requestId);
  await restore(page);
  await page.context().clearCookies({ name: "t035" });
  await page.reload();
  await expect(page).toHaveURL(/\/acceder\?error=sesion/);
  expect(new URL(page.url()).searchParams.get("next")).toBe(path);
  await actor(page, name);
  await page.goto(path);
  await expect(page.getByRole("tab", { name: "Recursos" })).toBeFocused();
  const results = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"]).analyze();
  await info.attach("axe-route.json", { body: JSON.stringify(results.violations), contentType: "application/json" });
  expect(results.violations.map(item => ({ id: item.id, targets: item.nodes.map(node => node.target) }))).toEqual([]);
});

test("F07 measures cold and warm catalog navigation with request and payload budgets", async ({ page }, info) => {
  const name = info.project.name === "mobile" ? "student-38" : "student-37";
  await actor(page, name);
  const ready = await (await page.request.get(`${api}/__test/ready`)).json();
  for (const key of ["small", "admission", "large"]) {
    const response = await page.request.post("/api/v2/guided-learning/enrollments", {
      data: { pathId: ready.fixtures[key].pathId }, headers: { "idempotency-key": crypto.randomUUID() },
    });
    expect(response.status()).toBe(200);
  }
  const samples: { mode: "cold" | "warm"; usableMs: number; bytes: number; trace: Trace[] }[] = [];
  for (const mode of ["cold", "warm"] as const) {
    for (let n = 0; n < (mode === "warm" && process.env.F07_BASELINE !== "true" ? 30 : 12); n++) {
      if (mode === "warm") await page.goto("/aprendizaje?tab=hoy");
      await page.request.post(`${api}/__test/trace/${name}`, { data: {} });
      const started = performance.now();
      if (mode === "cold") await page.goto("/aprendizaje?tab=rutas");
      else await page.getByRole("navigation", { name: "Secciones de Aprendizaje guiado" }).getByRole("link", { name: "Rutas", exact: true }).click();
      await expect(page.getByRole("heading", { name: "Rutas disponibles", exact: true })).toBeVisible();
      await expect(page.locator('a[href="/aprendizaje/rutas/t035-small"]').first()).toBeVisible();
      const usableMs = performance.now() - started;
      await page.waitForLoadState("networkidle");
      const trace: Trace[] = await (await page.request.get(`${api}/__test/trace/${name}`)).json();
      samples.push({ mode, usableMs, bytes: trace.reduce((sum, item) => sum + item.bytes, 0), trace });
    }
  }
  const measurements = info.outputPath("catalog-measurements.json");
  await writeFile(measurements, JSON.stringify({ samples, summary: ["cold", "warm"].map(mode => ({ mode,
    p75: percentile(samples.filter(s => s.mode === mode).map(s => s.usableMs), .75),
    p95: percentile(samples.filter(s => s.mode === mode).map(s => s.usableMs), .95),
  })) }, null, 2));
  await info.attach("catalog-measurements.json", { path: measurements, contentType: "application/json" });
  if (process.env.F07_BASELINE !== "true") {
    for (const sample of samples.filter(s => s.mode === "cold")) {
      expect(sample.trace.filter(t => /\/enrollments\/[^/]+\/state$/.test(t.path))).toHaveLength(0);
      expect(sample.trace.filter(t => t.path === "/v2/guided-learning/paths?limit=20&includeState=true")).toHaveLength(1);
      expect(sample.trace.filter(t => /^\/v[12]\/guided-learning\/home$/.test(t.path))).toHaveLength(0);
    }
  }
});
