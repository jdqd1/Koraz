import { test, expect, type Page } from "@playwright/test";

const api = "http://127.0.0.1:41035";
async function actor(page: Page, name: string) {
  await page.context().addCookies([{ name: "t035", value: name, domain: "127.0.0.1", path: "/" }]);
}
type Trace = { method: string; path: string; status: number; durationMs: number; bytes: number };
const percentile = (values: number[], p: number) => [...values].sort((a, b) => a - b)[Math.ceil(values.length * p) - 1]!;

test("F07 measures cold and warm catalog navigation with request and payload budgets", async ({ page }, info) => {
  const name = info.project.name === "mobile" ? "student-38" : "student-37";
  await actor(page, name);
  const samples = [];
  for (const mode of ["cold", "warm"] as const) {
    for (let n = 0; n < 12; n++) {
      if (mode === "warm") await page.goto("/aprendizaje?tab=hoy");
      await page.request.post(`${api}/__test/trace/${name}`, { data: {} });
      const started = performance.now();
      if (mode === "cold") await page.goto("/aprendizaje?tab=rutas");
      else await page.getByRole("navigation", { name: "Secciones de Aprendizaje guiado" }).getByRole("link", { name: "Rutas", exact: true }).click();
      await expect(page.getByRole("heading", { name: "Rutas disponibles", exact: true })).toBeVisible();
      await expect(page.locator('a[href="/aprendizaje/rutas/t035-small"]').first()).toBeVisible();
      const usableMs = performance.now() - started;
      const trace: Trace[] = await (await page.request.get(`${api}/__test/trace/${name}`)).json();
      samples.push({ mode, usableMs, bytes: trace.reduce((sum, item) => sum + item.bytes, 0), trace });
    }
  }
  await info.attach("catalog-measurements.json", { body: JSON.stringify({ samples, summary: ["cold", "warm"].map(mode => ({ mode,
    p75: percentile(samples.filter(s => s.mode === mode).map(s => s.usableMs), .75),
    p95: percentile(samples.filter(s => s.mode === mode).map(s => s.usableMs), .95),
  })) }, null, 2), contentType: "application/json" });
  if (process.env.F07_BASELINE !== "true") {
    for (const sample of samples.filter(s => s.mode === "cold")) {
      expect(sample.trace.filter(t => /\/enrollments\/[^/]+\/state$/.test(t.path))).toHaveLength(0);
    }
  }
});
