import { test, expect, type Page, type Locator } from "@playwright/test";

const api="http://127.0.0.1:41035";
const route="/aprendizaje/rutas/t035-small";
async function actor(page:Page,name:string){
  await page.context().addCookies([{name:"t035",value:name,domain:"127.0.0.1",path:"/"}]);
  await page.clock.setFixedTime(new Date("2026-10-04T12:00:00Z"));
}
async function server(page:Page,path:string){const r=await page.request.get(api+path);expect(r.ok()).toBeTruthy();return r.json();}
const fixture=async(page:Page,key="small")=>(await server(page,"/__test/ready")).fixtures[key];
async function state(page:Page){const path=await server(page,"/v2/guided-learning/paths/t035-small");return (await server(page,`/v2/guided-learning/enrollments/${path.path.enrollmentId}/state`)).state;}
async function enroll(page:Page){
  await page.goto(route);await page.getByRole("button",{name:"Comenzar",exact:true}).click();
  await expect(page.getByRole("button",{name:"Continuar",exact:true}).first()).toBeVisible();
}
async function launch(page:Page,key?:string){
  await page.goto(route);
  // SSR exposes the button before React attaches its event handler.
  await page.waitForFunction(()=>{const button=document.querySelector(".learning-path-hero button");return button && Object.keys(button).some(k=>k.startsWith("__reactProps"));});
  if(key){const current=await state(page);expect(current.maintenance.activities.map((a:{key:string})=>a.key)).toContain(key);
    await page.getByText("Refuerzo, repaso y mantenimiento",{exact:true}).click();
    const branches=page.getByRole("region",{name:"Otras ramas disponibles"});
    await branches.getByRole("button",{name:"Practicar este objetivo",exact:true}).first().click();
  }else await page.getByRole("button",{name:"Continuar",exact:true}).first().click();
  await expect(page).toHaveURL(/\/aprendizaje\/sesiones\//);
  await expect(page.getByRole("heading",{name:"Tu sesión de aprendizaje",exact:true})).toBeVisible();
  return page.url().split("/sesiones/")[1]!.split("?")[0]!;
}
async function feedback(page:Page|Locator){
  const button=page.getByRole("button",{name:/^(Continuar|Ver cierre de sesión)$/}).last();
  await expect(button).toBeVisible();await button.click();
}
async function finish(page:Page|Locator){await page.getByRole("button",{name:"Finalizar sesión",exact:true}).click();await expect(page.getByRole("heading",{name:"Sesión completada",exact:true})).toBeVisible();}
async function answer(page:Page|Locator,kind:string,wrong=false){
  if(kind==="study"){await page.getByRole("button",{name:"Continuar a la práctica"}).click();return;}
  if(kind==="single_choice"){await page.getByRole("radio",{name:wrong?"Respuesta B":"Respuesta A",exact:true}).check();await page.getByRole("button",{name:"Comprobar respuesta",exact:true}).click();}
  if(kind==="short_answer"){await page.getByLabel("Tu respuesta",{exact:true}).fill("respuesta");await page.getByRole("button",{name:"Comprobar respuesta",exact:true}).click();}
  if(kind==="constructed_response"){await page.getByLabel("Explica con tus palabras").fill("Una relación sintética.");await page.getByRole("button",{name:"Guardar mi respuesta"}).click();await page.getByRole("button",{name:"Comparar con el modelo"}).click();await expect(page.getByRole("heading",{name:"Respuesta modelo",exact:true})).toBeVisible();await page.getByRole("button",{name:"Lo recuperé",exact:true}).click();}
  if(kind==="match"){await page.getByRole("combobox",{name:"Origen",exact:true}).selectOption("c");await page.getByRole("button",{name:"Comprobar relaciones"}).click();}
  if(kind==="sequence"){await page.getByRole("button",{name:"Comprobar secuencia"}).click();}
  if(kind==="image_target"){await page.getByLabel("Horizontal (%)").fill("20");await page.getByLabel("Vertical (%)").fill("20");await page.getByRole("button",{name:"Comprobar respuesta visual"}).click();}
  if(kind==="case"){await expect(page.getByText("Etapa 2: relación sintética",{exact:true})).toHaveCount(0);await answer(page,"single_choice");await expect(page.getByText("Etapa 2: relación sintética",{exact:true})).toBeVisible();await answer(page,"short_answer");return;}
  await feedback(page);
}
const student=(base:number,mobile:boolean)=>`student-${base+(mobile?10:0)}`;

test("E01 creates a new persisted v2 draft using UI and keyboard",async({page},info)=>{
  await actor(page,"editor");await page.goto("/panel/rutas/nueva?mode=v2");
  await expect(page.locator('[data-engine-version="guided-v2"]')).toBeVisible();
  const press=async(l:Locator)=>{await l.focus();await l.press("Enter");};
  const type=async(l:Locator,value:string)=>{await l.focus();await l.pressSequentially(value);};
  await type(page.getByLabel("Título",{exact:true}),`Creación UI T035 ${info.project.name}`);
  await expect(page.getByLabel("Tema del catálogo").locator("option")).toHaveCount(2);
  await page.getByLabel("Tema del catálogo").focus();await page.getByLabel("Tema del catálogo").press("End");await page.getByLabel("Tema del catálogo").press("Tab");
  await expect(page.getByLabel("Tema del catálogo")).not.toHaveValue("");
  await type(page.getByLabel("Descripción",{exact:true}),"Borrador creado desde cero con fuentes sintéticas.");
  await press(page.getByRole("button",{name:"Añadir fuente",exact:true}));
  await expect(page.getByLabel("Guía y revisión").locator("option")).toHaveCount(2);
  await page.getByLabel("Guía y revisión").focus();await page.getByLabel("Guía y revisión").press("End");await page.getByLabel("Guía y revisión").press("Tab");
  await expect(page.getByLabel("Guía y revisión")).not.toHaveValue("");
  await type(page.getByLabel("Cita bibliográfica"),"Fuente sintética T035 (2026)");
  await type(page.getByLabel("Sección o encabezado"),"Fixture");await type(page.getByLabel("Fragmento de la fuente"),"Contenido sintético para comprobar el software.");
  await press(page.getByRole("tab",{name:"Objetivos",exact:true}));await type(page.getByLabel("Nombre de nueva unidad"),"Unidad desde cero");await press(page.getByRole("button",{name:"Añadir unidad",exact:true}));await press(page.getByRole("button",{name:"Añadir objetivo",exact:true}));await type(page.getByLabel("Capacidad observable"),"Aplicar una relación sintética");
  await page.getByRole("group",{name:"Fuentes del objetivo"}).getByRole("checkbox").focus();await page.keyboard.press("Space");
  const saved=page.waitForResponse(r=>r.request().method()==="POST" && r.url().endsWith("/api/v2/editor/learning-paths"));
  await press(page.getByRole("button",{name:"Guardar borrador",exact:true}));
  const response=await saved;expect(response.status(),await response.text()).toBe(200);
  const body=await response.json();expect(body.route.status).toBe("draft");expect(body.route.definition.objectives).toHaveLength(1);
  await expect(page).toHaveURL(new RegExp(`/panel/rutas/${body.route.pathId}`));await page.reload();await expect(page.getByRole("heading",{name:`Creación UI T035 ${info.project.name}`,exact:true})).toBeVisible();
});

test("E02 editorial preview has no learner effects, then publishes with current approval",async({page},info)=>{
  await actor(page,"editor");const f=await fixture(page,info.project.name==="mobile"?"editorial-mobile":"editorial");
  await page.goto(`/panel/rutas/${f.pathId}`);await page.getByRole("tab",{name:"Revisión",exact:true}).click();
  const before=await server(page,"/__test/counts");const learnerRequests:string[]=[];
  page.on("request",r=>{if(r.url().includes("/api/v2/guided-learning/"))learnerRequests.push(r.url());});
  await page.getByRole("button",{name:"Abrir vista previa",exact:true}).click();
  const preview=page.locator("[data-editor-preview]");await preview.getByLabel("Explorar un punto de la ruta").selectOption("activity:study-1");await preview.getByRole("button",{name:"Abrir punto seleccionado"}).click();await answer(preview,"study");await finish(preview);
  await preview.getByRole("button",{name:"Cerrar vista previa",exact:true}).first().click();
  expect(await server(page,"/__test/counts")).toEqual(before);expect(learnerRequests).toEqual([]);
  await page.getByRole("button",{name:"Enviar a revisión",exact:true}).click();await expect(page.getByRole("button",{name:"Aprobar revisión",exact:true})).toBeVisible();await page.getByRole("button",{name:"Aprobar revisión",exact:true}).click();await expect(page.getByRole("button",{name:"Publicar ruta",exact:true})).toBeVisible();await page.getByRole("button",{name:"Publicar ruta",exact:true}).click();await page.getByRole("button",{name:"Confirmar publicación",exact:true}).click();
  await expect(page.getByText("Publicada",{exact:true})).toBeVisible();const published=await server(page,`/v2/guided-learning/paths/${f.slug}`);expect(published.path.pathVersionId).toBe(f.versionId);
});

test("E03 beginner help and CORE error are confirmed by the server",async({page},info)=>{
  await actor(page,student(2,info.project.name==="mobile"));await enroll(page);
  for(const kind of ["study","constructed_response"]){await launch(page);await answer(page,kind);await finish(page);}
  const attemptId=await launch(page);await expect(page.getByText("Explicación sintética confirmada.",{exact:true})).toHaveCount(0);
  await page.getByRole("button",{name:"Necesito ayuda",exact:true}).click();await expect(page.getByRole("heading",{name:"Pista",exact:true})).toBeVisible();await answer(page,"single_choice",true);await finish(page);
  expect((await server(page,`/__test/responses/${attemptId}`)).rows).toEqual([{activity_key:"choice-1",assisted:true}]);
  const confirmed=await state(page);expect(confirmed.objectives[0].criticalErrorOpen).toBe(true);expect(confirmed.nextAction.kind).toBe("remediate");await page.goto(route);await expect(page.getByText("Confusión CORE sintética",{exact:true})).toBeVisible();
});

test("E04 all eight kinds persist through the learner UI on desktop and mobile",async({page},info)=>{
  test.setTimeout(240000);await actor(page,student(3,info.project.name==="mobile"));await enroll(page);
  for(const [key,kind] of [["study","study"],["constructed","constructed_response"],["choice","single_choice"],["short","short_answer"],["apply","single_choice"],["match","match"],["sequence","sequence"],["image","image_target"],["case","case"]]){
    const attemptId=await launch(page,`${key}-1`);await answer(page,kind!);await finish(page);
    const rows=(await server(page,`/__test/responses/${attemptId}`)).rows;expect(rows).toHaveLength(kind==="case"?2:1);
    const width=await page.evaluate(()=>({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth}));expect(width.scroll).toBeLessThanOrEqual(width.client+1);
  }
  const large=await fixture(page,"large");expect(large.objectives).toBe(200);await page.goto("/aprendizaje/rutas/t035-large");await expect(page.getByText("Aplicar el ejemplo 200",{exact:true})).toBeVisible();
});

test("E05 disconnect before/after commit, reload and two tabs preserve one answer",async({page,context},info)=>{
  test.setTimeout(240000);
  for(const [index,afterCommit] of [[0,false],[1,true]] as const){
    await actor(page,student(4+index,info.project.name==="mobile"));await enroll(page);const attemptId=await launch(page);
    const pattern="**/api/v2/guided-learning/attempts/*/responses";let resolve!:()=>void;const intercepted=new Promise<void>(r=>resolve=r);
    await page.route(pattern,async r=>{if(afterCommit){const response=await r.fetch();expect(response.status()).toBe(200);}await r.abort("failed");resolve();});
    await page.getByRole("button",{name:"Continuar a la práctica"}).click();await intercepted;
    await expect(page.getByText("Pendiente de confirmar",{exact:true})).toBeVisible();expect((await server(page,`/__test/responses/${attemptId}`)).rows).toHaveLength(afterCommit?1:0);
    await page.unroute(pattern);await page.reload();
    const retry=page.getByRole("button",{name:"Reintentar solicitud pendiente",exact:true});if(await retry.count())await retry.click();
    await expect(page.getByRole("button",{name:"Finalizar sesión",exact:true})).toBeVisible();await finish(page);expect((await server(page,`/__test/responses/${attemptId}`)).rows).toHaveLength(1);
  }
  await actor(page,student(6,info.project.name==="mobile"));await enroll(page);const attemptId=await launch(page);
  const other=await context.newPage();await other.clock.setFixedTime(new Date("2026-10-04T12:00:00Z"));await other.goto(page.url());
  await Promise.all([page,other].map(p=>p.getByRole("button",{name:"Continuar a la práctica"}).click()));
  await expect.poll(async()=>(await server(page,`/__test/responses/${attemptId}`)).rows.length).toBe(1);
  await Promise.all([page.reload(),other.reload()]);for(const p of [page,other])await expect(p.getByRole("button",{name:"Finalizar sesión",exact:true})).toBeVisible();await other.close();
});

test("E06 home, real map, route, session and review keep the pinned server state",async({page},info)=>{
  await actor(page,student(7,info.project.name==="mobile"));await enroll(page);
  const ready=await page.request.post(api+`/__test/map/${student(7,info.project.name==="mobile")}`,{data:{}});expect(ready.ok()).toBeTruthy();
  await page.goto("/aprendizaje?tab=hoy");await expect(page.getByText("Ruta T035 pequeña",{exact:true}).first()).toBeVisible();
  await page.goto("/aprendizaje/mapa");await page.getByRole("button",{name:"Abrir Tema T035",exact:true}).click();await expect(page.getByText("Ruta T035 pequeña",{exact:true}).first()).toBeVisible();
  await launch(page);await answer(page,"study");await finish(page);const confirmed=await state(page);
  await page.goto("/aprendizaje/repaso?motor=guided-v2&ruta=t035-small");await expect(page.getByRole("heading",{name:"Práctica y mantenimiento",exact:true})).toBeVisible();
  const current=await state(page);expect(current.pathVersionId).toBe(confirmed.pathVersionId);expect(current.objectives).toEqual(confirmed.objectives);expect(current.rowVersion).toBe(confirmed.rowVersion);
});
