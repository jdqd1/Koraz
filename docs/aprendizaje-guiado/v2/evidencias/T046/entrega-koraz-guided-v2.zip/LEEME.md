# Entrega local Koraz guided-v2

Instalación/documentación PASS local. Hito K original completo NO VERIFICADO.
Consulta docs/aprendizaje-guiado/v2/entrega/README.md y acta-HITO-K.md.

skill/crear-rutas-koraz contiene los 12 archivos exactos probados e instalados. Su validador requiere Node.js 24, sin repositorio/red/dependencias externas.
Los JSON de T045 contienen soluciones editoriales privadas. El sintético es ficticio y no médico; piloto y adversarial son borradores no publicables con incidencias.

Este archivo contiene una selección explícita de evidencias, identificada en ENTREGA-MANIFEST.json. Los enlaces a dossiers históricos no empaquetados requieren el repositorio original. No contiene la aplicación, bases de datos, todas las capturas ni los logs completos; no acredita despliegue, revisión médica nueva o producción.
